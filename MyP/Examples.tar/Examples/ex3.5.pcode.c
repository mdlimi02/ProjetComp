Error : symbol y is not a valid defined symbol
#include "PCode.h"

int main() { // Starts program target code

// Declare variable x of type float with offset 0 at depth 0
LOADF(0.0) // initial float value for x
